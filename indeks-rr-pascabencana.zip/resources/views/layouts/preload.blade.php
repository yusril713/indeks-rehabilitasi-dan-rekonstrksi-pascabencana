<div id="preload_ring">
    <div id="title_ring">
        Loading
        <span id="preload_span"></span>
    </div>
</div>

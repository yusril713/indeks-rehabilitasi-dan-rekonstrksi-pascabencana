
<?php $__env->startSection('title'); ?>
    <?php echo e($sektor->jenis); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <?php echo e($sektor->jenis); ?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><?php echo e($sektor->jenis); ?></li>
        </ol>
    </section>
    <section class="content">
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title"></h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <?php $__errorArgs = ['nilai.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e('Pastikan anda telah mengisi nilai di setiap pertanyaan!'); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <form action="#" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="table table-responsive">
                                
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th rowspan="2" class="vcenter" style="vertical-align: middle; "><?php echo e($sektor->jenis); ?></th>
                                            <th>2017</th>
                                            <th>2018</th>
                                            <th>2019</th>
                                            <th>2020</th>
                                            <th>2021</th>
                                            <tr>
                                                <th style="vertical-align: middle; ">Sebelum</th>
                                                <th style="vertical-align: middle; ">Saat</th>
                                                <th>Pasca 1</th>
                                                <th>Pasca 2</th>
                                                <th>Pasca 3</th>
                                            </tr>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sektor->sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iSektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th colspan="5"><?php echo e($iSektor->sektor); ?></th>
                                                
                                            </tr>
                                            <?php $__currentLoopData = $iSektor->pemulihan_sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class=""><?php echo e($item->pertanyaan); ?> <br> <p class="text-sm text-danger"><?php echo e($item->keterangan); ?></p></td>

                                                    <td class=""><input type="text" class="form-control" readonly></td>
                                                    <td class=""><input type="text" class="form-control" readonly></td>
                                                    <td class=""><input type="text" class="form-control" readonly></td>
                                                    <td class=""><input type="text" class="form-control" readonly></td>
                                                    <td class=""><input type="text" class="form-control" readonly></td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/sektor/readonly/index.blade.php ENDPATH**/ ?>
<table id="tb_responden" class="table table-bordered table-striped table-hover">
    <thead>
        <th>No</th>
        <th>No Responden</th>
        <th>Responden</th>
        <th>Provinsi</th>
        <th>Kabupaten</th>
        <th>Kecamatan</th>
        <th>Kelurahan</th>
        <th>Keterangan</th>
    </thead>
    <tbody>
        <?php
            $no = ($data->currentpage()-1)* $data->perpage() + 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?>.</td>
                <td><?php echo e($item->petugas_responden->no_responden); ?></td>
                <td><?php echo e($item->petugas_responden->nama_responden); ?></td>
                <td><?php echo e($item->prov->nama); ?></td>
                <td><?php echo e($item->kab->nama); ?></td>
                <td><?php echo e($item->kec->nama); ?></td>
                <td><?php echo e($item->kel->nama); ?></td>
                <td><a class="btn btn-primary btn-sm" href="<?php echo e(url('database/kuesioner-responden/' . $item->petugas_responden->id)); ?>">Lihat Kuesioner</a>
                <a class="btn btn-success btn-sm" href="<?php echo e(url('database/detail-responden/' . $item->id)); ?>">Lihat Data</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($data->onEachSide(5)->links()); ?>

<?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/database/responden-child.blade.php ENDPATH**/ ?>
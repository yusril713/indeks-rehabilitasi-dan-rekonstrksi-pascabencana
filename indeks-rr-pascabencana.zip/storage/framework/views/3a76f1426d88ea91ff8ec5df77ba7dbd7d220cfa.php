<?php $__env->startSection('title'); ?>
    Data Keterangan Tempat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Keterangan Tempat
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Data Keterangan Tempat</li>
        </ol>
    </section>


    <section class="content">
        <?php if($message = Session::get('success')): ?>
            <script>
                var msg = "<?php echo e($message); ?>";
                Swal.fire(
                    'Messages',
                    msg,
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Data Keterangan Tempat</h3>

                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('keterangan-tempat.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Data</a>
                </div>
            </div>
            <div class="box-body table-responsive">
                <table id="tb_keterangan_tempat" class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Provinsi</th>
                            <th>Kabupaten</th>
                            <th>Kecamatan</th>
                            <th>Kelurahan</th>
                            <th>Alamat</th>
                            <th>Tahun Bencana</th>
                            <th>Jenis Bencana</th>
                            <th>Status</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('keterangan-tempat.destroy')): ?>
                            <th colspan="2">Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo $__env->make('admin.ket-tempat.data-kettempat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </tbody>
                </table>
            </div>
            <div class="box-body">
                <?php echo e($data->links()); ?>

            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#tb_keterangan_tempat').DataTable({
                'paging'      : true,
                'lengthChange': true,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false,
                'responsive'  : true
            })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/ket-tempat/index.blade.php ENDPATH**/ ?>
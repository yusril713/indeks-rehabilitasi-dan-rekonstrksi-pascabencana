<?php $__env->startSection('title'); ?>
    Detail Responden
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    table.borderless td,table.borderless th{
        border: none !important;
    }
    .chart-container {
   display: flex;
}

    #legend ul {
    list-style: none;
    font: 12px Verdana;
    white-space: nowrap;
    }

    #legend li span {
    width: 36px;
    height: 12px;
    display: inline-block;
    margin: 0 5px 8px 0;
    vertical-align: -9.4px;
}
</style>
<?php
    $baseline = '';
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Detail Responden
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Detail Responden</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <section class="col-lg-12">
                <div class="box-tools pull-right" style="padding-bottom: 10px;">
                    <a href="#" id="print" class="btn btn-success btn-sm"><i class="fa fa-print"></i>&nbsp; Print</a>
                </div>
            </section>
            <section class="col-lg-4 connectedSortable" >
                <div class="box box-success" id="printArea1">
                    <div class="box-header with-border">
                        <h3 class="box-title">Detail Responden</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <table class="table borderless">
                            <tr>
                                <td>Nama Petugas</td>
                                <td>:</td>
                                <td><?php echo e($keterangan_tempat->petugas_responden->petugas->nama); ?></td>
                            </tr>
                            <tr>
                                <td>No Responden</td>
                                <td>:</td>
                                <td><?php echo e($keterangan_tempat->petugas_responden->no_responden); ?></td>
                            </tr>
                            <tr>
                                <td>No KK</td>
                                <td>:</td>
                                <td><?php echo e($keterangan_tempat->petugas_responden->no_kk); ?></td>
                            </tr>
                            <tr>
                                <td>Nama Responden</td>
                                <td>:</td>
                                <td><?php echo e($keterangan_tempat->petugas_responden->nama_responden); ?></td>
                            </tr>
                            <tr>
                                <td>Kelurahan</td>
                                <td>:</td>
                                <td><?php echo e($keterangan_tempat->kel->nama); ?></td>
                            </tr>
                            <tr>
                                <td>Tahun</td>
                                <td>:</td>
                                <td>
                                    <select name="tahun" id="tahun" class="form-control">
                                        <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i->tahun); ?>"><?php echo e($i->tahun); ?></option>
                                            <?php
                                                $baseline = $i->tahun;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            </tr>
                            <?php
                                $indeks = 0;
                            ?>
                            <?php $__currentLoopData = $ina_pdri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Sektor <?php echo e($sektor[$indeks]); ?> (Nilai)</td>
                                    <td>:</td>
                                    <td id="<?php echo e(str_replace(" ", "",$sektor[$indeks])); ?>"><?php echo e(round($item->hasil, 2)); ?> - <?php echo e($item->hasil >= 100 ? "Pulih" : "Belum Pulih"); ?></td>
                                    <?php
                                        $indeks++;
                                    ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><b>Kesimpulan</b></td>
                                <td>: </td>
                                <td id="rata_rata"></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="box box-primary" id="printArea2">
                    <div class="box-header with-border">
                        <h3 class="box-title">Indeks Pemulihan Sektor</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <canvas id="donutChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                    </div>
                </div>
            </section>

            <section class="col-lg-8 connectedSortable">
                <div class="box box-danger" id="printArea3">
                    <div class="box-header with-border">
                        <h3 class="box-title">Indeks Pemulihan Sektor</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="chart">
                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                </div>
            </section>

            <section class="col-lg-8 connectedSortable">
                <div class="box box-danger" id="printArea3">
                    <div class="box-header with-border">
                        <h3 class="box-title">Tabel Indeks Pemulihan Sektor</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <th>Sektor</th>
                                    <?php $__currentLoopData = $t_asc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($item->tahun); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ina_responden->groupBy('jenis_sektor_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td rowspan="2" style="vertical-align: middle;"><?php echo e($i[0]->jenis_sektor->jenis); ?></td>
                                        <?php
                                            $counter = 0;
                                        ?>
                                        <?php $__currentLoopData = $i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e(round($j->ina_pdri, 2)); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <?php $__currentLoopData = $i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><b>
                                            <?php if($counter == 0): ?>
                                                <?php echo e('Baseline'); ?>

                                            <?php else: ?>
                                                <?php if($j->ina_pdri >= 100): ?>
                                                    <p class="text-success"><?php echo e('Pulih'); ?></p>
                                                <?php else: ?>
                                                    <p class="text-danger"><?php echo e("Belum Pulih"); ?></p>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </b></td>
                                        <?php
                                            $counter++;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/print.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
<script>
$('#print').click(function() {
    printContent()
})

function printContent(pid) {
    document.getElementById('printArea1').disabled = !(pid === 'printArea1');
    document.getElementById('printArea2').disabled = !(pid === 'printArea2');
    document.getElementById('printArea3').disabled = !(pid === 'printArea3');
    window.print();
    return false;
}
function printForm() {
	printJS({
    printable: 'printable',
    type: 'html',
    targetStyles: ['*'],
    // header: 'PrintJS - Print Form With Customized Header'
 })
}

$(document).ready(function () {
    var url = "<?php echo e(url('database/detail-responden-ajax')); ?>/" + "<?php echo e($keterangan_tempat->id); ?>" + "/" + $('#tahun').val()
    ajaxChart(url)

    $('#tahun').change(function () {
        var url = "<?php echo e(url('database/detail-responden-ajax')); ?>/" + "<?php echo e($keterangan_tempat->id); ?>" + "/" + $(this).val()
        console.log(url)
        ajaxChart(url)
    })

    function ajaxChart(url) {
        var tahun_baseline = "<?php echo e($baseline); ?>"
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            success: function(arrObject) {
                // console.log(arrObject.ina_pdri.length)
                indeks = 0;
                // console.log(arrObject.ina_pdri[arrObject.ina_pdri.length-1].tahun);
                var sum = 0
                $.each(arrObject.ina_pdri, function(key, value) {
                    $('#' + arrObject.sektor[indeks].replace(" ", "")).html(
                        "<td>"
                        + value.hasil.toFixed(2) + " - " + (value.tahun == tahun_baseline ? "Baseline" : (value.hasil >= 100 ? "Pulih":"Belum Pulih")) +
                        "</td>"
                    )
                    sum += parseFloat(value.hasil.toFixed(2))
                    indeks++;
                })
                $('#rata_rata').html("<b>" + (sum/5).toFixed(2) + " - " + (  $('#tahun').val() == tahun_baseline ? "Baseline" : ((sum/5) >= 100 ? "Pulih":"Belum Pulih")) + "</b>")

                labels = []
                label = []
                data = []
                temp = '';
                for (i in arrObject.ina_pdri_all) {
                    if(arrObject.ina_pdri_all[i].jenis_sektor.jenis == temp) {
                    } else
                        labels.push(arrObject.ina_pdri_all[i].jenis_sektor.jenis);
                    label.push(arrObject.ina_pdri_all[i].tahun)
                    temp = arrObject.ina_pdri_all[i].jenis_sektor.jenis
                }
                label = getUnique(label)
                // console.log(label)
                var groups = { };
                arrObject.ina_pdri_all.forEach(function(item){
                    var list = groups[item.tahun];
                    if(list){
                        list.push(item);
                    } else{
                        groups[item.tahun] = [item];
                    }
                });
                // console.log(groups)
                avg = []
                var color = ['green', 'red', 'yellow', 'orange', 'blue']
                for (i = 0; i < label.length; i++) {
                    // console.log(groups[label[i]]);
                    data[i] = []
                    temp = 0
                    for (j = 0; j < groups[label[i]].length; j++) {
                        // console.log(groups[label[i]][j].ina_pdri);
                        data[i][j] = parseFloat(groups[label[i]][j].hasil).toFixed(2)
                        temp += groups[label[i]][j].hasil
                    }
                    avg.push(temp / groups[label[i]].length)
                    // color.push(random_rgba())
                }
                console.log(avg)
                datasets = []

                for (i = 0; i < label.length; i++) {
                    datasets.push({
                        // label               : label[i],
                        // fillColor           : color[i],
                        // strokeColor         : color[i],
                        // pointColor          : color[i],
                        // pointStrokeColor    : '#c1c7d1',
                        // pointHighlightFill  : '#fff',
                        // pointHighlightStroke: 'rgba(220,220,220,1)',
                        // data                : data[i],
                        // display             : true
                        label: label[i],
                        fill: false,
                        data: data[i],
                        backgroundColor: color[i],
                        borderColor: [
                            'rgba(255,99,132,1)',
                            'rgba(255,99,132,1)',
                            'rgba(255,99,132,1)',
                            'rgba(255,99,132,1)',
                            'rgba(255,99,132,1)',
                            'rgba(255,99,132,1)',
                        ],
                        borderWidth: 1
                    });
                }

                var ctx = document.getElementById("barChart");
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels:  ['PEMUKIMAN', 'INFRASTRUKTUR', 'SOSIAL', 'EKONOMI', 'LINTAS SEKTOR'],
                        datasets: datasets,
                    },
                    options: {
                        scales: {
                        yAxes: [{
                            ticks: {
                            beginAtZero: true
                            }
                        }]
                        },
                        title: {
                        display: true,
                        text: 'Indeks Pemulihan Sektor Per Responden'
                        },
                        responsive: true,

                        tooltips: {
                            callbacks: {
                                labelColor: function(tooltipItem, chart) {
                                return {
                                    borderColor: 'rgb(255, 0, 20)',
                                    backgroundColor: 'rgb(255,20, 0)'
                                }
                                }
                            }
                        },
                        legend: {
                            labels: {
                                // This more specific font property overrides the global property
                                fontColor: 'red',

                            }
                        }
                    }
                });


                //Doughnut Chart
                // console.log(label)
                // var chart = new Chart(ctx, {
                // type: 'doughnut',
                // data: {
                //     labels: label,
                //     datasets: [{
                //         data: avg,
                //         backgroundColor: color,
                //         borderColor: color
                //     }]
                // },
                // options: {
                //     responsive: true,
                //     legend: false,
                //     legendCallback: function(chart) {
                //         var ul = document.createElement('ul');
                //         var borderColor = chart.data.datasets[0].borderColor;
                //         chart.data.labels.forEach(function(label, index) {
                //             ul.innerHTML += `
                //                 <li>
                //                 <span style="background-color: ${borderColor[index]}"></span>
                //                 ${label}
                //             </li>
                //             `; // ^ ES6 Template String
                //         });
                //         return ul.outerHTML;
                //     }
                // }
                // });

                // legend.innerHTML = chart.generateLegend();
                //-------------
    //- DONUT CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
                var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
                var donutData        = {
                labels: label,
                datasets: [
                    {
                    data: avg,
                    backgroundColor : color,
                    }
                ]
                }
                var donutOptions     = {
                maintainAspectRatio : false,
                responsive : true,
                }
                //Create pie or douhnut chart
                // You can switch between pie and douhnut using the method below.
                new Chart(donutChartCanvas, {
                type: 'doughnut',
                data: donutData,
                options: donutOptions
                })
           },
           error: function(xhr) {
               console.log(xhr)
           }
        })
    }
    function random_rgba() {
        var o = Math.round, r = Math.random, s = 255;
        return 'rgba(' + o(r()*s) + ',' + o(r()*s) + ',' + o(r()*s) + ',' + r().toFixed(1) + ')';
    }
    function getUnique(array){
        var uniqueArray = [];
        // Loop through array values
        for(i=0; i < array.length; i++){
            if(uniqueArray.indexOf(array[i]) === -1) {
                uniqueArray.push(array[i]);
            }
        }
        return uniqueArray;
    }
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/database/detail-responden.blade.php ENDPATH**/ ?>
<table id="tb_responden" class="table table-bordered table-striped table-hover">
    <thead>
        <th>No</th>
        <th>Provinsi</th>
        <th>Kabupaten</th>
        <th>Kecamatan</th>
        <th>Kelurahan</th>
        <th>Keterangan</th>
    </thead>
    <tbody>
        <?php
            $no =  ($data->currentpage()-1)* $data->perpage() + 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?>.</td>
                <td><?php echo e($item->prov->nama); ?></td>
                <td><?php echo e($item->kab->nama); ?></td>
                <td><?php echo e($item->kec->nama); ?></td>
                <td><?php echo e($item->kel->nama); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/database/provinsi-child.blade.php ENDPATH**/ ?>
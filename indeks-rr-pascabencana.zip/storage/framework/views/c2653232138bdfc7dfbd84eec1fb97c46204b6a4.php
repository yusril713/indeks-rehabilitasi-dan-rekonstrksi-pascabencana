<?php $i=1; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td style="width: 10px"><?php echo e($i++); ?>.</td>
    <td><?php echo e($item->prov->nama); ?></td>
    <td><?php echo e($item->kab->nama); ?></td>
    <td><?php echo e($item->kec->nama); ?></td>
    <td><?php echo e($item->kel->nama); ?></td>
    <td><?php echo e($item->alamat); ?></td>
    <td><?php echo e($item->tahun_bencana); ?></td>
    <td><?php echo e($item->jenis_bencana); ?></td>
    <td>
        <?php if(auth()->check() && auth()->user()->hasRole('Super Admin|Level 3')): ?>
            <?php if($item->status == 'success'): ?>
                <?php echo e("FINISH"); ?>

            <?php else: ?>
                <a href="<?php echo e(route('manage-responden', [Crypt::encrypt($item->id)])); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i> Pending</a>
            <?php endif; ?>
        <?php else: ?>
            <?php if(Auth::user()->id == isset($item->user_id)): ?>
                <?php if($item->status == 'success'): ?>
                    <?php echo e("FINISH"); ?>

                <?php else: ?>
                    <a href="<?php echo e(route('manage-responden', [Crypt::encrypt($item->id)])); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i> Pending</a>
                <?php endif; ?>
            <?php else: ?>
                <?php if($item->status == 'success'): ?>
                    <?php echo e("FINISH"); ?>

                <?php else: ?>
                    <?php echo e("PENDING"); ?>

            <?php endif; ?>
        <?php endif; ?>
        <?php endif; ?>
    </td>
    <td>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-responden')): ?>
        <a href="<?php echo e(route('manage-responden', [Crypt::encrypt($item->id)])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> Edit</a>
        <?php endif; ?>
    </td>
    <td>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('keterangan-tempat.destroy')): ?>
        <form action="<?php echo e(route('keterangan-tempat.destroy', [Crypt::encrypt($item->id)])); ?>" method="post" onsubmit="return confirm('Are you sure want to remove this data?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>
        </form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/ket-tempat/data-kettempat.blade.php ENDPATH**/ ?>
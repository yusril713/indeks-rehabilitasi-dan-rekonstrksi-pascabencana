<?php $__env->startSection('title'); ?>
    Form Data Responden
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Form Data Responden
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Form Data Responden</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages!',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Form Data Responden</h3>
                <hr>

                <div class="box-body table-responsive" id="table_data">
                    <?php echo $__env->make('admin.database.responden-child', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $(document).on('click', '.page-link', function(event){
            event.preventDefault();
            var page = $(this).attr('href').split('page=')[1];
            console.log(page)
            fetchData(page);
        });
        function fetchData(page) {
            const SEKTOR = ["Pemukiman", "INFRASTRUKTUR", "SOSIAL", "EKONOMI", "LINTAS SEKTOR"]
            var url = "<?php echo e(url('database/responden/child')); ?>" ;
            $.ajax({
                method: 'GET',
                url: url,
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    page: page
                },
                success: function(data) {
                    $('#table_data').html(data)
                }
            })
        }

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/database/responden.blade.php ENDPATH**/ ?>
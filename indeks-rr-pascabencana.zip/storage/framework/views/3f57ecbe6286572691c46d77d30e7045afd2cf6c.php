<?php $__env->startSection('title'); ?>
    Data Foto Bencana
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Foto Bencana
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Data Foto Bencana</li>
        </ol>
    </section>

 
    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Data Foto Bencana</h3>

                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('manage-foto.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Data</a>
                </div>
            </div>
            <div class="box-body table-responsive">
                <table id="tb" class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th style="width: 10px">No.</th>
                            <th>Jenis Bencana</th>
                            <th>Foto</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1 ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <tr>
                                
                                <?php
                                    $counter = 0;
                                ?>
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                    <?php if($counter == 0): ?>
                                        <td rowspan="<?php echo e(sizeof($item)); ?>"><?php echo e($i++); ?></td>
                                        <td rowspan="<?php echo e(sizeof($item)); ?>"><?php echo e($key); ?></td>
                                        <td>
                                            <img src="<?php echo e(url('images/upload/'.$j->nama)); ?>" alt="" width="200" height="auto">    
                                        </td>
                                
                                        <th rowspan="<?php echo e(sizeof($item)); ?>">
                                            <form action="<?php echo e(route('manage-foto.destroy', [Crypt::encrypt($j->id)])); ?>" method="post" onsubmit="return confirm('Are you sure want to remove this data <?php echo e($key); ?>?')" style="display: inline">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>
                                            </form>
                                        </th>
                                    <?php else: ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(url('images/upload/'.$j->nama)); ?>" alt="" width="200" height="auto">    
                                            </td>
                                        </tr>
                                    <?php endif; ?>        
                                    <?php
                                        $counter++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/manage-foto/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>
    Form Data Responden
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Form Data Responden
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Form Data Responden</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages!',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Form Data Responden</h3>
                <hr>

                <div class="box-body table-responsive">
                    
                    
                    <table id="tb_responden" class="table table-bordered table-striped table-hover">
                        <thead>
                        <th>No</th>
                            <th>No Responden</th>
                            <th>Responden</th>
                            <th>Provinsi</th>
                            <th>Kabupaten</th>
                            <th>Kecamatan</th>
                            <th>Kelurahan</th>
                            <th colspan="2">Keterangan</th>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        const SEKTOR = ["Pemukiman", "INFRASTRUKTUR", "SOSIAL", "EKONOMI", "LINTAS SEKTOR"]
        var url = "<?php echo e(url('database/get-responden')); ?>" ;
        $.ajax({
            type: 'GET',
            url: url,
            dataType: 'json',
            success: function(data) {
                
                $('#tb_responden tbody').empty();
        
                var html =''
                var no = 1
                for (i in data.keterangan_tempat) {
                    // console.log(data.keterangan_tempat[i][0].kec.nama)
                    var url_href = "<?php echo e(url('database/detail-responden')); ?>" + "/" + data.keterangan_tempat[i].id
                    var url_kuesioner = "<?php echo e(url('database/kuesioner-responden')); ?>" + "/" + data.keterangan_tempat[i].petugas_responden.id
                    html += '<tr>'
                    html += '<td>' + (no++) + '</td>'
                    html += '<td>' + data.keterangan_tempat[i].petugas_responden.no_responden + '</td>'
                    html += '<td>' + data.keterangan_tempat[i].petugas_responden.nama_responden + '</td>'
                    html += '<td>' + data.keterangan_tempat[i].prov.nama + "</td>"
                    html += '<td>' + data.keterangan_tempat[i].kab.nama + '</td>';
                    html += '<td>' + data.keterangan_tempat[i].kec.nama + '</td>';
                    html += '<td>' + data.keterangan_tempat[i].kel.nama + '</td>';
                    html += '<td><a href="' + url_kuesioner + '" class="btn btn-primary btn-sm">Lihat Kuesioner</a></td>'
                    html += '<td><a href="' + url_href + '" class="btn btn-success btn-sm">Lihat Data</a></td>'
                    html += '/tr>'
                }
                $('#tb_responden tbody').append(html)
            }
        })
    });
</script>
<script>
    $(document).ready(function() {
            $('#tb_responden').DataTable({
                'paging'      : true,
                'lengthChange': true,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false,
                'responsive'  : true
            })
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/database/responden.blade.php ENDPATH**/ ?>
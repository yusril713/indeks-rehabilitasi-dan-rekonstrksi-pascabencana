<?php $__env->startSection('title'); ?>

    Data Galery

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>



<div class="content-wrapper">

    <section class="content-header">

        <h1>

            Galery

        </h1>

        <ol class="breadcrumb">

            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>

            <li>Index</li>

            <li class="active">Data Gallery</li>

        </ol>

    </section>





    <section class="content">

        <div class="box box-warning">

            <div class="box-header with-border">

                <h3 class="box-title">Data Gallery</h3>

            </div>

            <div class="box-body">

                <div class="row">

                    <?php

                        $counter = 1;

                    ?>

                    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-3 col-xs-6">

                                <div class="small-box">

                                    <div class="gallery">

                                        <a href="<?php echo e(url('images/upload/'.$j->nama)); ?>" data-fancybox="gallery" data-caption="<?php echo e($key); ?>, <?php echo e($j->bencana->prov->nama); ?>, <?php echo e($j->bencana->kab->nama); ?>, <?php echo e($j->bencana->kec->nama); ?>, <?php echo e($j->bencana->kel->nama); ?>">

                                            <div class="embed-responsive embed-responsive-16by9">

                                            <img src="<?php echo e(url('images/upload/'.$j->nama)); ?>" class="embed-responsive-item"  style="padding: 2px 2px;" alt="">

                                            </div>

                                        </a>

            

                                        <div class="caption embed-responsive-item">

                                            <p style="color: black"><?php echo e($key); ?>, <?php echo e($j->bencana->prov->nama); ?>, <?php echo e($j->bencana->kab->nama); ?>, <?php echo e($j->bencana->kec->nama); ?>, <?php echo e($j->bencana->kel->nama); ?></p>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            </div>

            

        </div>



    </section>

</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

    <script>

        $(document).ready(function() {

            $("[data-fancybox]").fancybox({

                protect: true

            });

        });

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/galeri/index.blade.php ENDPATH**/ ?>
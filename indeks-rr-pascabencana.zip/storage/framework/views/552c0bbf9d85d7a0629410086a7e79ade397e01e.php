<?php $__env->startSection('title'); ?>
    Tambah Keterangan Tempat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Keterangan Tempat
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('keterangan-tempat.index')); ?>"> Keterangan Tempat</a></li>
            <li class="active">Tambah</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Good job!',
                    'You clicked the button!',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Tambah Keterangan Tempat</h3>

                
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-5 col-md-offset-3">
                        <form id="ff" action="<?php echo e($edit ? route('keterangan-tempat.update', [Crypt::encrypt($data->id)]) : route('keterangan-tempat.store')); ?>" class="form-horizontal" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if($edit): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                            <input type="hidden" name="prov_id" id="prov_id" value="<?php echo e(!$edit ? old('prov_id') :  $data->prov->id); ?>">
                            <input type="hidden" name="kab_id" id="kab_id" value="<?php echo e(!$edit  ? old('kab_id') :  $data->kab->id); ?>">
                            <input type="hidden" name="kec_id" id="kec_id" value="<?php echo e(!$edit  ? old('kec_id') : $data->kec->id); ?>">
                            <input type="hidden" name="kel_id" id="kel_id" value="<?php echo e(!$edit  ? old('kel_id') : $data->kel->id); ?>">
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="kabupaten" class="col-sm-4 control-label">Jenis Bencana</label>
                                    <div class="col-sm-8">
                                        <select class="form-control select2 <?php $__errorArgs = ['jenis_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_bencana" name="jenis_bencana">
                                            <option value="">Pilih Bencana</option>
                                            <?php $__currentLoopData = $bencana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?> <?php echo e($item->jenis_bencana); ?>" <?php echo e(!$edit ? (old('jenis_bencana') == $item->jenis_bencana ? 'selected' : '') : ($data->id == $item->id ? 'selected' : '')); ?>><?php echo e($item->jenis_bencana); ?> - <?php echo e($item->kec->nama); ?>, <?php echo e($item->kel->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['jenis_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label for="provinsi" class="col-sm-4 control-label">Provinsi</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="provinsi" id="provinsi" class="form-control" readonly>
                                        <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="kabupaten" class="col-sm-4 control-label">Kabupaten/ Kota</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="kabupaten" id="kabupaten" readonly>
                                        <?php $__errorArgs = ['kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            
                                <div class="form-group">
                                    <label for="kecamatan" class="col-sm-4 control-label">Kecamatan</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="kecamatan" id="kecamatan" class="form-control" readonly>
                                        <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            
                                <div class="form-group">
                                    <label for="kelurahan" class="col-sm-4 control-label">Desa/ Kelurahan</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="kelurahan" id="kelurahan" class="form-control" readonly>
                                        <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="alamat" class="col-sm-4 control-label">Alamat</label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" id="alamat" cols="30" rows="3"><?php echo e(!$edit ? old('alamat') : $data->alamat); ?></textarea>
                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="kabupaten" class="col-sm-4 control-label">Tahun Terjadi Bencana</label>
                                    <div class="col-sm-8">
                                        <select class="form-control <?php $__errorArgs = ['tahun_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tahun_bencana" name="tahun_bencana">
                                            <option selected value="">Pilih Tahun</option>
                                            <?php for($i = date('Y'); $i >= 2012; $i--): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e(!$edit ? (old('tahun_bencana') == $i ? 'selected' : '') : ($data->tahun_bencana == $i ? 'selected' : '')); ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <?php $__errorArgs = ['tahun_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                

                            </div>

                            <div class="col-md-8 col-md-offset-4">
                                <div class="pull-right">
                                    <button type="submit" class="btn btn-success btn-sm bt_save"><i class="fa fa-save"></i> Simpan</button>
                                </div>
                                
                                <div class="pull-left">
                                    <a href="<?php echo e(route('keterangan-tempat.index')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-backward"></i>&nbsp; Kembali</a>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function () {

    });
</script>

<script>
    $(document).ready(function() {
        id = $('#jenis_bencana').val().split(" ")
            var url = "<?php echo e(url('keterangan_tempat/get-bencana')); ?>/" + id[0];
            ajaxGet(url)

        $('#jenis_bencana').change(function () {
            id = $(this).val().split(" ")
            var url = "<?php echo e(url('keterangan_tempat/get-bencana')); ?>/" + id[0];
            ajaxGet(url)
        }) 

        // Initialize Select2 Elements

        $('.bt_save').click(function() {
            $('.alert-danger').fadeIn();
        });

        //$('.alert-danger').fadeOut(5000);
        setTimeout(function(){ $('.alert-danger').fadeOut(); }, 5000);

        $('.bt_clear').click(function() {
            $('#ff')[0].reset();
            $('.select2').select2().reset();
        });
    });

    function ajaxGet(url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            success: function(data) {
                console.log(data)
                $('#provinsi').val(data.prov.nama)
                $('#kabupaten').val(data.kab.nama)
                $('#kecamatan').val(data.kec.nama)
                $('#kelurahan').val(data.kel.nama)
                $('#alamat').text(data.alamat)

                $('#prov_id').val(data.prov.id)
                $('#kab_id').val(data.kab.id)
                $('#kec_id').val(data.kec.id)
                $('#kel_id').val(data.kel.id)
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/ket-tempat/create.blade.php ENDPATH**/ ?>
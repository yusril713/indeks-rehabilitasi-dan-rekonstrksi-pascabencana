<?php $__env->startSection('title'); ?>
    Edit Assign Permission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Assign Permission
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('manage-role.index')); ?>"> Assign Permission</a></li>
            <li class="active">Edit</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages',
                    'You clicked the button!',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Assign Permission</h3>

                
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="ff" action="<?php echo e(route('assign-permission.store')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data"  onsubmit="return confirm('Yakin ingin menyimpan data tersebut?')">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">
                                <input type="hidden" name="role_id" value="<?php echo e($role_has_pemissions->id); ?>">

                                <div class="form-group">
                                    <label for="nama" class="col-sm-2 control-label">Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="role" id="role" value="<?php echo e($role_has_pemissions->name); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="nama" class="col-sm-2 control-label">Guard Name</label>
                                    <div class="col-sm-10">
                                        <select class="form-control select2" name="permissions[]" id="choices-multiple-remove-button" multiple>
                                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->name); ?>"
                                                    <?php if(isset($role_has_pemissions->permissions)): ?>
                                                        <?php $__currentLoopData = $role_has_pemissions->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rhp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($rhp->name == $item->name): ?>
                                                                <?php echo e('selected'); ?>

                                                                <?php
                                                                    break;
                                                                ?>
                                                            <?php else: ?>
                                                                <?php echo e(''); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    ><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-8 col-md-offset-4">
                                <div class="pull-right">
                                    <button type="submit" class="btn btn-success btn-sm bt_save"><i class="fa fa-save"></i> Simpan</button>
                                </div>

                                <div class="pull-left">
                                    <a href="<?php echo e(route('manage-role.index')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-backward"></i>&nbsp; Kembali</a>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
         $(document).ready(function(){
            var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
                removeItemButton: true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/assign-permission/edit.blade.php ENDPATH**/ ?>
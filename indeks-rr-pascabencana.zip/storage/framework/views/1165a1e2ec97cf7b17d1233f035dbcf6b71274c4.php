<div id="preload_ring">
    <div id="title_ring">
        Loading
        <span id="preload_span"></span>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/layouts/preload.blade.php ENDPATH**/ ?>
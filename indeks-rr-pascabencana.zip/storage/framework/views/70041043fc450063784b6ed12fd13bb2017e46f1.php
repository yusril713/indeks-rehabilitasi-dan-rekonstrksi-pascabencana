<div id="preload_ring">
    <div id="title_ring">
        Loading
        <span id="preload_span"></span>
    </div>
</div>
<?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/layouts/preload.blade.php ENDPATH**/ ?>
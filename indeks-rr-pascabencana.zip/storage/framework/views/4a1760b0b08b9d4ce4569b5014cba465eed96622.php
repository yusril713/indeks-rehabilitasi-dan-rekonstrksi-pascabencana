<?php $__env->startSection('title'); ?>
    Data Petugas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Petugas
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Data Petugas</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages!',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Data Petugas</h3>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-petugas.create')): ?>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('manage-petugas.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Data</a>
                </div>
                <?php endif; ?>
            </div>

            <div class="box-body table-responsive">
                <table id="tb" class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>NIP</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Jenis Kelamin</th>
                            <th>TTL</th>
                            <th>No Hp</th>
                            <th>Alamat</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($item->nip); ?></td>
                               <td><?php echo e($item->nama); ?></td>
                               <td><?php echo e(isset($item->user->email) ? $item->user->email : '-'); ?></td>
                               <td><?php echo e($item->jenis_kelamin == 'L' ? "Pria" : "Wanita"); ?></td>
                               <td><?php echo e($item->tempat_lahir); ?>, <?php echo e($item->tgl_lahir); ?></td>
                               <td><?php echo e($item->no_hp); ?></td>
                               <td><?php echo e($item->alamat); ?></td>
                               <td>
                                   <?php if(auth()->check() && auth()->user()->hasRole('Super Admin|Level 3')): ?>
                                   <a href="<?php echo e(route('manage-petugas.edit', [Crypt::encrypt($item->id)])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                   <?php else: ?>
                                    <?php if(Auth::user()->id == isset($item->user->id)): ?>
                                    <a href="<?php echo e(route('manage-petugas.edit', [Crypt::encrypt($item->id)])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-petugas.destroy')): ?>
                                   <form action="<?php echo e(route('manage-petugas.destroy', [Crypt::encrypt($item->id)])); ?>" method="post" style="display: inline" onsubmit="return confirm('Yakin ingin menghapus data tersebut?')">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('DELETE'); ?>
                                       <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>
                                   </form>
                                   <?php endif; ?>
                               </td>
                           </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indeks_rr\resources\views/admin/manage-petugas/index.blade.php ENDPATH**/ ?>
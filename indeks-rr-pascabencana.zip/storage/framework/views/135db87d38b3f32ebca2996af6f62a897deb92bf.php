
<?php $__env->startSection('title'); ?>
    Form Data Kabupaten
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Form Data Kabupaten
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Form Data Kabupaten</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages!',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Form Data Kabupaten</h3>
                <hr>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="provinsi" id="provinsi" class="form-control">
                                    <option value="">Pilih Provinsi</option>
                                    <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                <div class="box-body table-responsive">
                    
                    
                    <table id="tb_responden" class="table table-bordered table-striped table-hover">
                        <thead>
                            <th>Kabupaten</th>
                            <th>Kecamatan</th>
                            <th>Kelurahan</th>
                            <th>Keterangan</th>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        const SEKTOR = ["Pemukiman", "INFRASTRUKTUR", "SOSIAL", "EKONOMI", "LINTAS SEKTOR"]
        $('#provinsi').change(function() {
            $('#kecamatan')
                .find('option')
                .remove()
                .end()
                .append('<option value="">Pilih Kecamatan</option>')
                .val('');

            var prov_id = $(this).val();
            var url = "<?php echo e(url('database/get-kabupaten')); ?>" + "/" + prov_id;
            $.ajax({
                type: 'GET',
                url: url,
                dataType: 'json',
                success: function(data) {
                   
                    $('#tb_responden tbody').empty();
                    $('#kabupaten')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value="">Pilih Kabupaten</option>')
                        .val('');
                    const dataGroup = data.keterangan_tempat.reduce((acc, value) => {
                        // Group initialization
                        if (!acc[value.kabupaten]) {
                            acc[value.kabupaten] = [];
                        }
                        
                        // Grouping
                        acc[value.kabupaten].push(value);
                        
                        return acc;
                    }, {});
                    var html =''
                    for (i in dataGroup) {
                        // console.log(dataGroup[i][0].kec.nama)
                        html += '<tr><td rowspan="'+ dataGroup[i].length +'">' + dataGroup[i][0].kab.nama + "</td>"
                        var url_href = "<?php echo e(url('database/detail-kabupaten')); ?>" + "/" + dataGroup[i][0].kab.id
                        for (j = 0; j < dataGroup[i].length; j++) {
                            if (j == 0) {
                                html += '<td>' + dataGroup[i][j].kec.nama + '</td>';
                                html += '<td>' + dataGroup[i][j].kel.nama + '</td>';
                                html += '<td rowspan="' + dataGroup[i].length + '"><a href="'+url_href+'" class="btn btn-success">Lihat Data</a></td>'
                            } else {

                                html += '<tr><td>' + dataGroup[i][j].kec.nama + '</td>'
                                html += '<td>' + dataGroup[i][j].kel.nama + '</td></tr>'
                            }
                        }
                        html += '/tr>'
                    }
                    $('#tb_responden tbody').append(html)
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/database/kabupaten.blade.php ENDPATH**/ ?>
<div class="alert alert-danger">You dont have permission to access this page!!!</div>
<?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/layouts/alert.blade.php ENDPATH**/ ?>
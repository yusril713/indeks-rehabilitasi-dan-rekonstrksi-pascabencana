<?php $__env->startSection('title'); ?>
    Tambah Foto Bencana
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Foto Bencana
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('manage-foto.index')); ?>"> Foto Bencana</a></li>
            <li class="active">Tambah</li>
        </ol>
    </section>


    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages',
                    'Your images has been successfully',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Tambah Foto Bencana</h3>

                
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-5 col-md-offset-3">
                        <form id="ff" action="<?php echo e(route('manage-foto.store')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="box-body">

                                <div class="form-group">
                                    <label for="" class="col-sm-4 control-label">Data Bencana</label>
                                    <div class="col-sm-8">
                                        <select class="form-control select2 <?php $__errorArgs = ['id_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_bencana" name="id_bencana">
                                            <option value="" selected>Pilih Jenis Bencana</option>
                                            <?php $__currentLoopData = $bencana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e(old('id_bencana') == $item->id ? 'selected' : ''); ?>><?php echo e(date('d-m-Y', strtotime($item->tgl_bencana))); ?> - <?php echo e($item->jenis_bencana); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_bencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="nama" class="col-sm-4 control-label">Masukan Foto</label>
                                    <div class="col-sm-8">
                                        <input type="file" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" id="nama">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                            </div>

                            <div class="col-sm-8 col-sm-offset-4">
                                <div class="pull-right">
                                    <button type="submit" class="btn btn-success btn-sm bt_save"><i class="fa fa-save"></i> Simpan</button>
                                </div>

                                <div class="pull-left">
                                    <a href="<?php echo e(route('manage-foto.index')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-backward"></i>&nbsp; Kembali</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function () {

    });
</script>

<script>
    $(document).ready(function() {
        //Initialize Select2 Elements
        

        $('.bt_save').click(function() {
            $('.alert-danger').fadeIn();
        });

        //$('.alert-danger').fadeOut(5000);
        setTimeout(function(){ $('.alert-danger').fadeOut(); }, 5000);

        $('.bt_clear').click(function() {
            $('#ff')[0].reset();
            $('.select2').select2().reset();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/manage-foto/create.blade.php ENDPATH**/ ?>
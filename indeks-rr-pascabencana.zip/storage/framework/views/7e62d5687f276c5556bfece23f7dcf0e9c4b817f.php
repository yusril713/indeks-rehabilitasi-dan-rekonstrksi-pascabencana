<?php $__env->startSection('title'); ?>
    <?php echo e($sektor->jenis); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $yearSurveiMin1 = $survei->keterangan_tempat->tahun_bencana - 1;
    $currentYear = date('Y');
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <?php echo e($sektor->jenis); ?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><?php echo e($sektor->jenis); ?></li>
        </ol>
    </section>
    <section class="content">
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title"></h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('survei.sektor-sosial', [Crypt::encrypt($survei->id), Crypt::encrypt(3)])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-backward"></i>&nbsp; Kembali</a>
                </div>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="form_pemukiman" action="<?php echo e(route('sektor-infrastruktur.store',  [Crypt::encrypt($survei->id), Crypt::encrypt(5), 'lintas-sektor'])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="table table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th rowspan="2" class="vcenter" style="vertical-align: middle; "><?php echo e($sektor->jenis); ?></th>
                                            <?php for($i = $yearSurveiMin1; $i <= $currentYear; $i++): ?>
                                                <th style=""><?php echo e($i); ?></th>
                                            <?php endfor; ?>
                                            <tr>
                                                <th style="vertical-align: middle; ">Sebelum</th>
                                                <th style="vertical-align: middle; ">Saat</th>
                                                <?php if($currentYear > Carbon\Carbon::createFromFormat('Y-m-d', $survei->tgl_survei)->year): ?>
                                                <th style="vertical-align: middle; " colspan="<?php echo e($currentYear - Carbon\Carbon::createFromFormat('Y-m-d', $survei->tgl_survei)->year); ?>">Pasca Bencana</th>
                                                <?php endif; ?>
                                            </tr>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sektor->sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iSektor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th colspan="<?php echo e($currentYear - Carbon\Carbon::createFromFormat('Y-m-d', $survei->tgl_survei)->year + 3); ?>"><?php echo e($iSektor->sektor); ?></th>
                                            </tr>
                                            <?php $__currentLoopData = $iSektor->pemulihan_sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class=""><?php echo e($item->pertanyaan); ?> <br> <p class="text-sm text-danger"><?php echo e($item->keterangan); ?></p></td>
                                                    <?php for($i = $yearSurveiMin1; $i <= $currentYear; $i++): ?>
                                                    <input type="hidden" name="survei_id[]" value="<?php echo e($survei->id); ?>">
                                                    <input type="hidden" name="kuesioner_id[]" value="<?php echo e($survei->id); ?>">
                                                    <input type="hidden" name="tahun[]" value="<?php echo e($i); ?>">
                                                        <td class=""><input type="text"  id="<?php echo e($survei->id); ?><?php echo e($item->id); ?><?php echo e($i); ?>" name="nilai[]" data-survei_id="<?php echo e($survei->id); ?>" data-kuesioner_id="<?php echo e($item->id); ?>" data-tahun="<?php echo e($i); ?>" class="form-control nilai" value="<?php echo e(count($detail_survei->where('kuesioner_id', $item->id)->where('tahun', $i)) > 0 ? $detail_survei->where('kuesioner_id', $item->id)->where('tahun', $i)->first()->nilai : ''); ?>"></td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="box-footer pull-right">
                                <button type="submit" class="btn btn-success">Next</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('.nilai').on('keyup', function() {
            kuesioner_id = $(this).data('kuesioner_id');
            tahun = $(this).data('tahun');
            survei_id = $(this).data('survei_id')
            nilai = $(this).val();
            console.log(kuesioner_id);
            $inputs = $('#form_pemukiman').find("input, select, button, textarea")

            if (nilai == "") {

            } else {

                data = {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'kuesioner_id': kuesioner_id,
                    'survei_id': survei_id,
                    'tahun': tahun,
                    'nilai': nilai,
                };
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('/kinerja-pemulihan/post')); ?>",
                    data: data,
                    beforeSend: function(){
                        $inputs.prop("disabled", true);
                    },
                    success: function(data) {
                        $("input, select, button, textarea").removeAttr("disabled");
                    }, error: function(xhr) {
                        $("input, select, button, textarea").removeAttr("disabled");
                        if (nilai == null || nilai == ""){}
                        else 
                        alert('Gagal menyimpan data')
                        $('#'+survei_id+kuesioner_id+tahun).val("")
                    }
                });
            }
        });
    });
</script>
<script>
    $(".nilai").on("keypress keyup blur",function (event) {
         //this.value = this.value.replace(/[^0-9\.]/g,'');
        $(this).val($(this).val().replace(/[^0-9\.]/g,''));
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });

    $(".nilai").on("keypress keyup blur",function (event) {
        $(this).val($(this).val().replace(/[^\d].+/, ""));
        if ((event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/sektor/ekonomi.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>
    Form Data Kuesioner
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    table.borderless td,table.borderless th{
        border: none !important;
    }
    .chart-container {
   display: flex;
}

    #legend ul {
    list-style: none;
    font: 12px Verdana;
    white-space: nowrap;
    }

    #legend li span {
    width: 36px;
    height: 12px;
    display: inline-block;
    margin: 0 5px 8px 0;
    vertical-align: -9.4px;
}   
</style>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Form Data Kuesioner
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li>Index</li>
            <li class="active">Form Data Kuesioner</li>
        </ol>
    </section>

    <section class="content">
        <?php if(session('status')): ?>
            <script>
                Swal.fire(
                    'Messages!',
                    'Data successfully created...',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="box box-warning" id="printable1">
            
            <div class="box-header with-border">
                <div class="box-tools pull-right" style="padding-bottom: 10px;">
                    <a href="#" id="print" class="btn btn-success btn-sm"><i class="fa fa-print"></i>&nbsp; Print</a>
                </div>
                <h3 class="box-title">Form Data Kuesioner</h3>
                <hr>
                <div class="row">
                    <div class="col-md-5">
                        <table class="table borderless">
                            <tr>
                                <td>No Responden</td>
                                <td>:</td>
                                <td><?php echo e($responden->no_responden); ?></td>
                            </tr>
                            <tr>
                                <td>No Kartu Keluarga</td>
                                <td>:</td>
                                <td><?php echo e($responden->no_kk); ?></td>
                            </tr>
                            <tr>
                                <td>Nama Responden</td>
                                <td>:</td>
                                <td><?php echo e($responden->nama_responden); ?></td>
                            </tr>
                            <tr>
                                <td>Lokasi Asal</td>
                                <td>:</td>
                                <td><?php echo e($responden->lokasi_asal); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="box-body table-responsive">
                            <table class="table table-striped table-bordered" id="printable2">
                                <thead>
                                    <th></th>
                                    <?php
                                        $t = -1;
                                    ?>
                                    <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($t == -1): ?>
                                            <th><?php echo e($item->tahun); ?><br> t - 1</th>                                        
                                        <?php else: ?>
                                            <th><?php echo e($item->tahun); ?> <br> t + <?php echo e($t); ?></th>
                                        <?php endif; ?>
                                        <?php
                                            $t++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $survei; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($key); ?></th>
                                        </tr>
                                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <td><b><?php echo e($key2); ?></b></td>
                                            </tr>
                                            <?php $__currentLoopData = $i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key3 => $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key3); ?></td>
                                                <?php $__currentLoopData = $j; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                                                    <td><?php echo e($k->nilai); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$('#print').click(function() {
    printContent()
})

function printContent(pid) {
    document.getElementById('printable1').disabled = !(pid === 'printable1');
    document.getElementById('printable2').disabled = !(pid === 'printable2');
    window.print();
    return false;
}
</script>
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sics9124/public_html/ina-pdri/resources/views/admin/database/kuesioner.blade.php ENDPATH**/ ?>
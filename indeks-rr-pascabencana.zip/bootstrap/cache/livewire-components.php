<?php return array (
  'admin.country' => 'App\\Http\\Livewire\\Admin\\Country',
  'admin.country-edit' => 'App\\Http\\Livewire\\Admin\\CountryEdit',
);